#
```yaml
v1.1.6
```
```markdown
- updated for the latest bepinex build (5.4.2333).
- updated for the latest valheim build (221.4) call to arms update.
```


<details>
<summary><b>Changelog History</b> (<i>click to expand</i>)</summary>
<br/>

#
```yaml
v1.1.5
```
```markdown
- updated serversync.
```
```yaml
v1.1.4
```
```markdown
- updated for the latest valheim build (219.13) bog witch
```
```yaml
v1.1.3
```
```markdown
- minor code fixes and updated serversync
```
```yaml
v1.1.2
```
```markdown
- updated to the latest valheim build (217.28)
- updated serversync and dependencies
- updated manifests bepinex dependency string
```
```yaml
v1.1.1
```
```markdown
- removed server enforcement.
```
```yaml
v1.1.0
```
```markdown
- fixed multiplayer version check issues
```
```yaml
v1.0.9
```
```markdown
- updated to the latest valheim build (217.22)
```
```yaml
v1.0.8
```
```markdown
- updated to the latest valheim build (217.14) hilders request.
```
```yaml
v1.0.7
```
```markdown
- updated to the latest valheim build (216.9)
```
```yaml
v1.0.6
```
```markdown
- fixed eitr degradation
- added eitr benefits configuration
- updated to the latest valheim and bepinex builds.
```
```yaml
v1.0.5
```
```markdown
- added food degradation option (As Requested)
- configurable health and stamina benefits from foods
```
```yaml
v1.0.4
```
```markdown
- code optimized and updated serversync
```
```yaml
v1.0.3
```
```markdown
- added version checks
- update to latest valheim assemblies
```
```yaml
v1.0.2
```
```markdown
- fixed errors on dedicated servers running on linux
```
```yaml
v1.0.1
```
```markdown
- added config watcher.
```
```yaml
v1.0.0
```
```markdown
- first release
```

</details>