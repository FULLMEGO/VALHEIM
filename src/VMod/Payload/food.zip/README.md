># <b># FoodDurationMultiplier</b>

Multiplies the duration of all foods according to the value of Duration Multiplier. Configurable Food Degradation, Health, Stamina and Eitr Benefits from foods.

<br/>

>## ## Installation (manual)

- extract `FoodDurationMultiplier.dll` file to your `BepInEx\Plugins` folder

<br/>

>## ## Features

- Configurable food duration multiplier.
- Configurable food degradation.
- Configurable food benefits.
- Uses ServerSync to sync configs from server to client
- Uses built in config watcher.
- Configurable through config file or [Configuration Manager](https://valheim.thunderstore.io/package/Azumatt/Official_BepInEx_ConfigurationManager/)
