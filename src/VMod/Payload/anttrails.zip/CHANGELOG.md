# Changelog

## 1.0.0

### Valheim 1.0 support

The 1.0 update renamed or reshaped three of the game APIs AntTrails depends on — the world
name it keys save data on, the zone identifier used to decide which tiles are loaded, and
the terrain rebuild call it makes after painting. Rebuilt against 1.0.7 (Unity 6). This
release does not run on 0.221.x, and 0.2.x does not run on 1.0.

**Existing trails survive the update.** The world name the game hands out is unchanged in
value despite the rename, so `BepInEx/config/AntTrails/<worldname>.trails` is found and
loaded exactly as before. Wear counters, formation progress and stone upgrades all carry
over.

### Dependencies

BepInExPack 5.4.2350 and Jotunn 2.29.2.

### Note for servers

The minor version is part of the mod's network compatibility check, so 0.2.x clients
cannot join a 1.0.0 server or vice versa. Everyone updates together.

## 0.2.0

### Retuned formation, so that paths actually form

The old defaults could not produce a path in ordinary play. Formation progress leaks at a
flat `StepsToPath / FormationWindowDays` per in-game day, which at 60 and 4 meant a tile
shed a crossing every two real minutes. Unless you re-crossed the same square metre more
often than that, its progress sat at zero forever, however many hours you spent on the
route — a five-minute round trip to a mine never stood a chance. Formation was a contest of
rate, and the rate was set past what walking anywhere can produce.

| Setting | Old | New |
|---|---|---|
| `StepsToPath` | `60` | `25` |
| `FormationWindowDays` | `4` | `12` |
| `StoneSteps` | `1200` | `400` |
| `StoneChance` | `0.004` | `0.01` |

Break-even is now one crossing every quarter hour of real time rather than every two
minutes, and a route you keep using wears through over a few hours of play. Stone needs
roughly 500 lifetime crossings on a tile instead of about 1450, which no tile was ever
going to reach — the busiest ground in any base sits inside a workbench radius the mod
deliberately skips.

**Updating will not change settings you already have.** BepInEx writes the config file the
first time the mod runs and never overwrites it afterwards, so an existing
`BepInEx/config/com.ragemedia.anttrails.cfg` keeps the old values. To take up the new
tuning, either edit those four keys to the values in the table or delete the file and let
it regenerate. On a dedicated server, edit the *server's* copy: these keys are admin-only
and pushed out to clients.

### Wear is now traced between position samples

The client sampled its position four times a second and credited only the tile underfoot.
At a run that is more than a metre of travel per sample, so consecutive credited tiles were
not even adjacent: crossings went missing and trails came out dotted rather than
continuous. Each sample now credits every tile on the line back to the previous sample, so
a route wears the same whether you stroll it or sprint it. Eligibility — farmland, lava,
build privilege — is checked at each tile's centre, where the wear actually lands.

### Fixed

- The fallback day length used when the game's own value is unavailable was 1200 seconds
  against an actual 1800, running decay 50% fast for as long as it applied.

### Note for servers

The minor version is part of the mod's network compatibility check, so 0.1.x clients cannot
join a 0.2.0 server or vice versa. Everyone updates together.

## 0.1.2

- Added an MIT license.
- Set `website_url` in the manifest so the Thunderstore listing links to the source repo.

No functional or behavioural changes; the plugin itself is identical to 0.1.1.

## 0.1.1

- Widened the allowed range on `StepsToPath`, `RevertDays`, and `StoneSteps`. The previous
  minimums (5, 1 day, and 50 respectively) were arbitrary and sat above the values needed to
  observe path formation, decay, and the stone upgrade inside a single play session.

## 0.1.0
- Initial release.
