# Changelog

## v1.1.1
- Uploaded the proper file.

## v1.1.0

This update improves camera control, shoulder peek usability, and general polish while keeping the mod focused on immersive building. No freecam, no creative-mode tools, no placement cheats.

### Added

- Smooth camera movement while immersive build camera is active.
- Dedicated camera distance controls:
  - `PageUp` moves the camera closer.
  - `PageDown` moves the camera farther.
- Hold-to-adjust camera distance behavior.
  - Holding `PageUp` or `PageDown` now continuously adjusts the camera distance.
  - No more repeated tapping.
- New camera distance config options:
  - `CameraDistanceCloserKey`
  - `CameraDistanceFartherKey`
  - `DefaultBuildCameraDistance`
  - `MinBuildCameraDistance`
  - `MaxBuildCameraDistance`
  - `ScrollDistanceStep`
  - `RememberScrollDistance`
- New camera smoothing config:
  - `CameraTransitionSpeed`
- Debug logging option:
  - `EnableDebugLogs`

### Changed

- Shoulder peek defaults are stronger and more useful:
  - `ShoulderOffsetX` increased to `0.90`
  - `ShoulderDistance` increased to `0.55`
- Camera distance adjustment is now handled through dedicated keybinds instead of mouse wheel input.

### Fixed

- Fixed camera distance adjustment conflicting with Valheim's build-piece rotation.
- Mouse wheel is now left alone for Valheim's normal building controls.
- Fixed camera distance controls requiring repeated taps by allowing held input.

## v0.2.3

### Added
- Added local player renderer hiding while immersive build camera is active.
- Added `HideLocalPlayerWhenImmersive` config option.
- Added `ToggleShoulderPeek` config option.
- Shoulder peek can now be used as either hold-to-peek or toggle-to-peek.

### Changed
- The local player character is hidden only while immersive build camera is active and shoulder peek is not active.
- The local player character is restored while shoulder peeking so players can keep spatial awareness.

### Fixed
- Reduced cases where the player's head or body blocks the immersive build camera view.

## 0.2.2

Initial public release.

- Added toggleable immersive build camera
- Added configurable build camera keybind
- Added left and right shoulder peek
- Added configurable shoulder peek offsets
- Added collision handling for shoulder peek
- Added toggleable precision movement
- Added configurable precision movement multiplier
- Added BepInEx config support
- Uses `com.geronimo.valheim.immersivebuildcamera` as plugin GUID