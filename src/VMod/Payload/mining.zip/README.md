# ExtraSkillMining

Adds a mining skill that increases damage and yield against ores, while adding in a bonus extra ability to potentially "pop" the whole ore vein.