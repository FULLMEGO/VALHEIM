![](https://staticdelivery.nexusmods.com/mods/3667/images/2981/2981-1741115282-1720486903.png)


## Description
Allows tree stumps to regrow into the tree they once were after a configurable amount of time. Default regrowth time is 1800 seconds (30 minutes). The new tree retains the original tree's rotation and scale. Also displays growth time remaining on stumps (configurable).

Configuration is synced between connected clients via ServerSync allowing server admins to define regrowth time.

## Installing

### Manual Install

Install on dedicated server (if present) and all connected clients.

Extract the Advize_StumpsRegrow.dll file into the BepInEx/plugins folder.
Directory structure should look like this:
```
BepInEx ->
    plugins ->
        Advize_StumpsRegrow.dll
```

## Contact Author
You can reach me on NexusMods to provide bug reports or feedback https://www.nexusmods.com/valheim/mods/2981

For further mod or mod dev support, I can be found at the following Discord server:

[![](https://i.imgur.com/HZMpQip.png)](https://discord.gg/89bBsvK5KC)

## Config and Other Info:
Mod is configurable, a config file will be generated after first loading the mod and can be found in BepInEx/config/advize.StumpsRegrow.cfg

The config can be edited out of game with a text editor, or modified in game using the Configuration Manager mod.

## Source
Github Repo: [Advize_ValheimMods](https://github.com/AdvizeGH/Advize_ValheimMods)