**<details><summary>Version 1.0.5</summary>**

- Added explicit compatibility for leveled trees in StarLevelSystem by MidnightMods.
</details>
<details><summary>Version 1.0.4</summary>

- Ensures a minimum of 10 seconds between stump regrowth attempts, preventing a single stump from erroneously spawning multiple trees.
</details>
<details><summary>Version 1.0.3</summary>

- Updated ServerSync internally to v1.18.
</details>
<details><summary>Version 1.0.2</summary>

- Now correctly writes config file to disk.
</details>
<details><summary>Version 1.0.1</summary>

- Correctly require the mod to be installed on all clients in multiplayer.
- Updated documentation.
</details>
<details><summary>Version 1.0.0</summary>

- Created mod.
</details>